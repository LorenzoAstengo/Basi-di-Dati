-- CREAZIONE DATABASE

CREATE SCHEMA "bd1";

SET SEARCH_PATH TO "bd1";

CREATE TABLE utente (
    email VARCHAR(20) NOT NULL,
    bonus BOOL NOT NULL DEFAULT FALSE,
    ammontare NUMERIC(6, 2) NOT NULL DEFAULT 0,
    PRIMARY KEY (email)
);
CREATE TABLE abbonamento (
    data_inizio DATE NOT NULL,
    data_fine DATE NOT NULL,
    num_smartcard INT NOT NULL,
    email VARCHAR(20) NOT NULL REFERENCES utente,
    costo NUMERIC(6, 2) NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    carta_carburante INT NOT NULL,
    PRIMARY KEY (data_inizio, email),
    FOREIGN KEY (email) REFERENCES utente(email)
);
CREATE TABLE azienda (
    partita_iva VARCHAR(11) NOT NULL,
    indirizzo_sede_legale VARCHAR(100) NOT NULL,
    ragione_sociale VARCHAR(20) NOT NULL,
    nome_referente VARCHAR(20) NOT NULL,
    cognome_referente VARCHAR(20) NOT NULL,
    telefono_referente VARCHAR(10) NOT NULL,
    indirizzo_sede_op VARCHAR(100) NULL,
    data_nascita_rappr DATE NOT NULL,
    luogo_nascita_rappr VARCHAR(40) NOT NULL,
    cognome_rappr VARCHAR(20) NOT NULL,
    nome_rappr VARCHAR(20) NOT NULL,
    settore_attivita VARCHAR(20) NOT NULL,
    telefono VARCHAR(10) NOT NULL,
    email VARCHAR(20) NOT NULL,
    PRIMARY KEY (partita_iva),
    FOREIGN KEY (email) REFERENCES utente(email),
    CONSTRAINT azienda_telefono_key UNIQUE (telefono),
    CONSTRAINT azienda_email_key UNIQUE (email)
);
CREATE TABLE privato (
    codice_fiscale VARCHAR(16) NOT NULL,
    indirizzo_residenza VARCHAR(100) NOT NULL,
    professione VARCHAR(20) NOT NULL,
    genere CHAR(1) NOT NULL,
    email VARCHAR(20) NOT NULL,
    PRIMARY KEY (codice_fiscale),
    FOREIGN KEY (email) REFERENCES utente(email),
    CONSTRAINT privato_email_key UNIQUE (email)
);
CREATE TABLE carta_di_credito (
    numero VARCHAR(16) NOT NULL,
    circuito VARCHAR(20) NOT NULL,
    data_scadenza DATE NULL,
    email VARCHAR(20) NOT NULL,
    PRIMARY KEY (numero),
    FOREIGN KEY (email) REFERENCES utente(email),
    CONSTRAINT carta_di_credito_data_scadenza_check CHECK ((data_scadenza > CURRENT_DATE))
);
CREATE TABLE categoria (
    tipo VARCHAR(20) NOT NULL,
    PRIMARY KEY (tipo)
);
CREATE TABLE modello (
    nome_modello VARCHAR(20) NOT NULL,
    produttore VARCHAR(20) NOT NULL,
    numero_posti SMALLINT NOT NULL,
    numero_porte SMALLINT NOT NULL,
    velocita_massima SMALLINT NOT NULL,
    consumo_medio NUMERIC(4, 2) NOT NULL,
    airbag BOOL NULL,
    servosterzo BOOL NULL,
    aria_condizionata BOOL NULL,
    altezza SMALLINT NOT NULL,
    lunghezza SMALLINT NOT NULL,
    larghezza SMALLINT NOT NULL,
    bagagliaio SMALLINT NOT NULL,
    cilindrata SMALLINT NULL,
    kw SMALLINT NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    PRIMARY KEY (nome_modello, produttore),
    FOREIGN KEY (tipo) REFERENCES bd1.categoria(tipo),
    CONSTRAINT modello_altezza_check CHECK (altezza > (0)),
    CONSTRAINT modello_bagagliaio_check CHECK (bagagliaio > (0)),
    CONSTRAINT modello_cilindrata_check CHECK (cilindrata > (0)),
    CONSTRAINT modello_consumo_medio_check CHECK (consumo_medio > (0)),
    CONSTRAINT modello_kw_check CHECK ( kw > (0) ),
    CONSTRAINT modello_larghezza_check CHECK (larghezza > (0)),
    CONSTRAINT modello_numero_posti_check CHECK (numero_posti > (0)),
    CONSTRAINT modello_velocita_massima_check CHECK (velocita_massima > (0))
);
CREATE TABLE parcheggio (
    nome VARCHAR(20) NOT NULL,
    longitudine VARCHAR(20) NOT NULL,
    latitudine VARCHAR(20) NOT NULL,
    zona VARCHAR(20) NOT NULL,
    indirizzo VARCHAR(40) NOT NULL,
    num_posti SMALLINT NOT NULL,
    PRIMARY KEY (nome),
    CONSTRAINT parcheggio_num_posti_check CHECK (num_posti > (0))
);
CREATE TABLE vettura (
    targa VARCHAR(7) NOT NULL,
    nome VARCHAR(20) NOT NULL,
    colore VARCHAR(20) NOT NULL,
    chilometraggio INT NOT NULL,
    seggiolini SMALLINT NOT NULL,
    trasporto_animali BOOL NULL,
    nome_parcheggio VARCHAR(20) NOT NULL,
    nome_modello VARCHAR(20) NOT NULL,
    produttore VARCHAR(20) NOT NULL,
    PRIMARY KEY (targa),
    FOREIGN KEY (nome_modello, produttore) REFERENCES modello(nome_modello, produttore),
    FOREIGN KEY (nome_parcheggio) REFERENCES parcheggio(nome),
    CONSTRAINT vettura_chilometraggio_check CHECK (chilometraggio >= (0)),
    CONSTRAINT vettura_nome_key UNIQUE (nome),
    CONSTRAINT vettura_seggiolini_check CHECK (seggiolini >= (0))
);
CREATE TABLE prenotazione (
    id SERIAL,
    data_ritiro TIMESTAMP NOT NULL,
    data_consegna TIMESTAMP NOT NULL,
    targa VARCHAR(7) NOT NULL,
    data_ritiro_e TIMESTAMP NULL,
    data_consegna_e TIMESTAMP NULL,
    penale NUMERIC(6, 2) NULL DEFAULT 0,
    km_percorsi SMALLINT NULL DEFAULT 0,
    data_annullamento TIMESTAMP NULL,
    data_consegna_mod TIMESTAMP NULL,
    email VARCHAR(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (email) REFERENCES utente(email),
    FOREIGN KEY (targa) REFERENCES vettura(targa),
    CONSTRAINT prenotazione_check CHECK ((data_consegna > data_ritiro)),
    CONSTRAINT data_ritiro_e CHECK ((data_ritiro_e > data_ritiro)),
    CONSTRAINT prenotazione_km_percorsi_check CHECK (km_percorsi >= (0)),
    CONSTRAINT prenotazione_penale_check CHECK (penale >= (0))
);
CREATE TABLE rid (
    coordinate VARCHAR(27) NOT NULL,
    email VARCHAR(20) NOT NULL,
    PRIMARY KEY (coordinate),
    FOREIGN KEY (email) REFERENCES utente(email)
);
CREATE TABLE rifornimento (
    data_rifornimento TIMESTAMP NOT NULL,
    targa VARCHAR(7) NOT NULL,
    litri SMALLINT NOT NULL,
    chilometraggio INT NOT NULL,
    CONSTRAINT rifornimento_chilometraggio_check CHECK (chilometraggio > (0)),
    CONSTRAINT rifornimento_litri_check CHECK (litri > (0)),
    PRIMARY KEY (data_rifornimento, targa),
    FOREIGN KEY (targa) REFERENCES vettura(targa)
);
CREATE TABLE tariffa (
    nome_modello VARCHAR(20) NOT NULL,
    produttore VARCHAR(20) NOT NULL,
    supplemento_giornaliero NUMERIC(5, 2) NOT NULL,
    giornaliera NUMERIC(5, 2) NOT NULL,
    settimanale NUMERIC(5, 2) NOT NULL,
    oraria NUMERIC(5, 2) NOT NULL,
    chilometrica NUMERIC(4, 2) NOT NULL,
    PRIMARY KEY (nome_modello, produttore),
    FOREIGN KEY (nome_modello, produttore) REFERENCES modello(nome_modello, produttore),
    CONSTRAINT tariffa_chilometrica_check CHECK (chilometrica >= (0)),
    CONSTRAINT tariffa_giornaliera_check CHECK (giornaliera > (0)),
    CONSTRAINT tariffa_oraria_check CHECK (oraria > (0)),
    CONSTRAINT tariffa_settimanale_check CHECK (settimanale > (0)),
    CONSTRAINT tariffa_supplemento_giornaliero_check CHECK (supplemento_giornaliero > (0))
);
CREATE TABLE conducente (
    num_patente VARCHAR(20) NOT NULL,
    codice_fiscale VARCHAR(16) NULL,
    categoria_patente VARCHAR(20) NOT NULL,
    num_carta_identita VARCHAR(9) NOT NULL,
    luogo_nascita VARCHAR(40) NOT NULL,
    data_nascita DATE NOT NULL,
    cognome VARCHAR(20) NOT NULL,
    nome VARCHAR(20) NOT NULL,
    indirizzo_residenza VARCHAR(40) NOT NULL,
    partita_iva VARCHAR(11) NULL,
    PRIMARY KEY (num_patente),
    FOREIGN KEY (codice_fiscale) REFERENCES privato(codice_fiscale),
    FOREIGN KEY (partita_iva) REFERENCES azienda(partita_iva)
);
CREATE TABLE incidente (
    data_incidente TIMESTAMP NOT NULL,
    targa VARCHAR(7) NOT NULL,
    luogo VARCHAR(40) NOT NULL,
    danni VARCHAR(100) NULL,
    dinamica VARCHAR(100) NULL,
    num_patente VARCHAR(20) NOT NULL,
    PRIMARY KEY (data_incidente, targa),
    FOREIGN KEY (num_patente) REFERENCES conducente(num_patente),
    FOREIGN KEY (targa) REFERENCES vettura(targa)
);
CREATE TABLE testimoni (
    telefono VARCHAR(10) NOT NULL,
    nome VARCHAR(20) NOT NULL,
    cognome VARCHAR(20) NOT NULL,
    PRIMARY KEY (telefono)
);
CREATE TABLE testimonia (
    telefono VARCHAR(10) NOT NULL,
    data_incidente TIMESTAMP NOT NULL,
    targa VARCHAR(7) NOT NULL,
    PRIMARY KEY (telefono, data_incidente, targa),
    FOREIGN KEY (data_incidente, targa) REFERENCES incidente(data_incidente, targa),
    FOREIGN KEY (telefono) REFERENCES testimoni(telefono)
);
CREATE TABLE conducente_esterno (
    targa VARCHAR(7) NOT NULL,
    cognome VARCHAR(20) NOT NULL,
    nome VARCHAR(20) NOT NULL,
    PRIMARY KEY (targa)
);
CREATE TABLE coinvolge (
    targa_esterna VARCHAR(7) NOT NULL,
    data_incidente TIMESTAMP NOT NULL,
    targa VARCHAR(7) NOT NULL,
    PRIMARY KEY (targa_esterna, data_incidente, targa),
    FOREIGN KEY (data_incidente, targa) REFERENCES incidente(data_incidente, targa),
    FOREIGN KEY (targa_esterna) REFERENCES conducente_esterno(targa)
);
CREATE TABLE ospita (
    nome VARCHAR(20) NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    FOREIGN KEY (nome) REFERENCES parcheggio(nome),
    FOREIGN KEY (tipo) REFERENCES categoria(tipo)
);
-----------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------

-- INSERIMENTI

-- UTENTE
INSERT INTO utente (email, bonus, ammontare)
    VALUES ('marco123@gmail.com', TRUE, 0.00);
INSERT INTO utente (email, bonus, ammontare)
    VALUES ('alice123@gmail.com', FALSE, 60.00);
INSERT INTO utente (email, bonus, ammontare)
    VALUES ('sara123@gmail.com', FALSE, 0.00);
INSERT INTO utente (email, bonus, ammontare)
    VALUES ('abc@gmail.com', FALSE, 0.00);
INSERT INTO utente (email, bonus, ammontare)
    VALUES ('luca_rossi@gmail.com', TRUE, 45.00);
INSERT INTO utente (email, bonus, ammontare)
    VALUES ('qwe@gmail.com', FALSE, 145.00);
INSERT INTO utente (email, bonus, ammontare)
    VALUES ('ttt2@gmail.com', FALSE, 0.00);
INSERT INTO utente (email, bonus, ammontare)
    VALUES ('giovanni93@gmail.com', FALSE, 30.00);

-- PRIVATO
INSERT INTO privato (codice_fiscale, indirizzo_residenza, professione, genere, email)
    VALUES ('PLTKXN68A48F476J', 'via torino 10, GE', 'studente', 'f', 'alice123@gmail.com');
INSERT INTO privato (codice_fiscale, indirizzo_residenza, professione, genere, email)
    VALUES ('BRKAUK31P67F160X', 'corso saracco 47, GE', 'impiegato', 'm', 'marco123@gmail.com');
INSERT INTO privato (codice_fiscale, indirizzo_residenza, professione, genere, email)
    VALUES ('SRTRNH55P21F080Q', 'via tommasini 11, GE', 'tecnico', 'm', 'giovanni93@gmail.com');
INSERT INTO privato (codice_fiscale, indirizzo_residenza, professione, genere, email)
    VALUES ('NABRMD43A11F921T', 'via san paolo 33, GE', 'impiegato', 'm', 'luca_rossi@gmail.com');
INSERT INTO privato (codice_fiscale, indirizzo_residenza, professione, genere, email)
    VALUES ('PBHFTO76W83M220J', 'via borgo nuovo 19, GE', 'dottore', 'f', 'sara123@gmail.com');

-- AZIENDA
INSERT INTO azienda (partita_iva, indirizzo_sede_legale, ragione_sociale, nome_referente, cognome_referente,
                     telefono_referente, indirizzo_sede_op, data_nascita_rappr, luogo_nascita_rappr, cognome_rappr,
                     nome_rappr, settore_attivita, telefono, email)
    VALUES ('18530718725', 'via verdi 12, GE', 'a', 'Luca', 'Pestarino', '3474432867', 'corso italia 11, GE',
            '1993-02-14', 'Brescia, MI', 'Barbieri', 'Filippo', 'Intermediazione', '3434268530', 'abc@gmail.com');
INSERT INTO azienda (partita_iva, indirizzo_sede_legale, ragione_sociale, nome_referente, cognome_referente,
                     telefono_referente, indirizzo_sede_op, data_nascita_rappr, luogo_nascita_rappr, cognome_rappr,
                     nome_rappr, settore_attivita, telefono, email)
    VALUES ('24136243257', 'via rossi 43, GE', 'b', 'Amedeo', 'Simoni', '3453086284', NULL, '1974-04-05', 'Voltri, GE',
            'Grandi', 'Francesco', 'Intermediazione', '3406005944', 'qwe@gmail.com');
INSERT INTO azienda (partita_iva, indirizzo_sede_legale, ragione_sociale, nome_referente, cognome_referente,
                     telefono_referente, indirizzo_sede_op, data_nascita_rappr, luogo_nascita_rappr, cognome_rappr,
                     nome_rappr, settore_attivita, telefono, email)
    VALUES ('82031669341', 'via nerone 10, GE', 'a', 'Tom', 'Scarpa', '3430089211', NULL, '1988-02-01', 'Genova',
            'Gualco', 'Andrea', 'Commercio', '3951738638', 'ttt2@gmail.com');

-- RID
INSERT INTO rid (coordinate, email)
    VALUES ('0000157841Z', 'sara123@gmail.com');
INSERT INTO rid (coordinate, email)
    VALUES ('0000139721L', 'ttt2@gmail.com');

-- CARTA DI CREDITO
INSERT INTO carta_di_credito (numero, circuito, data_scadenza, email)
    VALUES ('4556783724286910', 'Mastercard', '2025-01-21', 'marco123@gmail.com');
INSERT INTO carta_di_credito (numero, circuito, data_scadenza, email)
    VALUES ('4485967408516132', 'Visa', '2022-03-09', 'abc@gmail.com');
INSERT INTO carta_di_credito (numero, circuito, data_scadenza, email)
    VALUES ('4400961403416111', 'Visa', '2023-04-13', 'giovanni93@gmail.com');
INSERT INTO carta_di_credito (numero, circuito, data_scadenza, email)
    VALUES ('4226702724255550', 'Mastercard', '2021-02-09', 'luca_rossi@gmail.com');

-- PARCHEGGIO
INSERT INTO parcheggio (nome, longitudine, latitudine, zona, indirizzo, num_posti)
    VALUES ('Villa borghese', '86', '21', 'sestri', 'via rossi 13', 10);
INSERT INTO parcheggio (nome, longitudine, latitudine, zona, indirizzo, num_posti)
    VALUES ('Caboto', '86', '22', 'brignole', 'via caboto 44', 24);
INSERT INTO parcheggio (nome, longitudine, latitudine, zona, indirizzo, num_posti)
    VALUES ('Piazza rossa', '87', '21', 'albaro', 'piazza rossa 15', 36);
INSERT INTO parcheggio (nome, longitudine, latitudine, zona, indirizzo, num_posti)
    VALUES ('Piazza cavour', '85', '21', 'sturla', 'piazza cavour 33', 30);
INSERT INTO parcheggio (nome, longitudine, latitudine, zona, indirizzo, num_posti)
    VALUES ('Pellico', '87', '20', 'principe', 'via pellico 10', 20);

-- CATEGORIA
INSERT INTO categoria (tipo)
    VALUES ('City car');
INSERT INTO categoria (tipo)
    VALUES ('Comfort');
INSERT INTO categoria (tipo)
    VALUES ('Elettrico');
INSERT INTO categoria (tipo)
    VALUES ('Cargo');
INSERT INTO categoria (tipo)
    VALUES ('Media');

-- OSPITA
INSERT INTO ospita (nome, tipo)
    VALUES ('Villa borghese', 'Elettrico');
INSERT INTO ospita (nome, tipo)
    VALUES ('Piazza cavour', 'City car');
INSERT INTO ospita (nome, tipo)
    VALUES ('Piazza cavour', 'Comfort');
INSERT INTO ospita (nome, tipo)
    VALUES ('Pellico', 'City car');
INSERT INTO ospita (nome, tipo)
    VALUES ('Piazza rossa', 'Comfort');
INSERT INTO ospita (nome, tipo)
    VALUES ('Piazza rossa', 'Media');
INSERT INTO ospita (nome, tipo)
    VALUES ('Piazza rossa', 'City car');
INSERT INTO ospita (nome, tipo)
    VALUES ('Piazza rossa', 'Elettrico');
INSERT INTO ospita (nome, tipo)
    VALUES ('Caboto', 'Cargo');
INSERT INTO ospita (nome, tipo)
    VALUES ('Caboto', 'Media');

-- MODELLO
INSERT INTO modello (nome_modello, produttore, numero_posti, numero_porte, velocita_massima, consumo_medio, airbag,
                     servosterzo, aria_condizionata, altezza, lunghezza, larghezza, bagagliaio, cilindrata, kw, tipo)
    VALUES ('Panda 1.3 Multijet', 'Fiat', 4, 5, 160, 4.30, TRUE, TRUE, TRUE, 3540, 1580, 1540, 775, 1248, 51,
            'City car');
INSERT INTO modello (nome_modello, produttore, numero_posti, numero_porte, velocita_massima, consumo_medio, airbag,
                     servosterzo, aria_condizionata, altezza, lunghezza, larghezza, bagagliaio, cilindrata, kw, tipo)
    VALUES ('Leaf', 'Nissan', 5, 5, 144, 4.30, TRUE, TRUE, TRUE, 1550, 4445, 1770, 1110, NULL, 80, 'Elettrico');
INSERT INTO modello (nome_modello, produttore, numero_posti, numero_porte, velocita_massima, consumo_medio, airbag,
                     servosterzo, aria_condizionata, altezza, lunghezza, larghezza, bagagliaio, cilindrata, kw, tipo)
    VALUES ('Up', 'Volkswagen', 4, 5, 130, 3.60, TRUE, TRUE, TRUE, 1504, 3600, 1645, 923, NULL, 60, 'Elettrico');
INSERT INTO modello (nome_modello, produttore, numero_posti, numero_porte, velocita_massima, consumo_medio, airbag,
                     servosterzo, aria_condizionata, altezza, lunghezza, larghezza, bagagliaio, cilindrata, kw, tipo)
    VALUES ('Ducato 35', 'Fiat', 3, 3, 150, 4.20, TRUE, TRUE, TRUE, 2254, 4963, 2050, 1640, 2200, 83, 'Cargo');
INSERT INTO modello (nome_modello, produttore, numero_posti, numero_porte, velocita_massima, consumo_medio, airbag,
                     servosterzo, aria_condizionata, altezza, lunghezza, larghezza, bagagliaio, cilindrata, kw, tipo)
    VALUES ('GOLF SPORTVAN', 'Volkswagen', 5, 5, 200, 4.60, TRUE, TRUE, TRUE, 1580, 4340, 1810, 1202, 1395, 125,
            'Comfort');

-- TARIFFA
INSERT INTO tariffa (nome_modello, produttore, supplemento_giornaliero, giornaliera, settimanale, oraria, chilometrica)
    VALUES ('Panda 1.3 Multijet', 'Fiat', 41.00, 50.00, 290.00, 3.25, 0.25);
INSERT INTO tariffa (nome_modello, produttore, supplemento_giornaliero, giornaliera, settimanale, oraria, chilometrica)
    VALUES ('Leaf', 'Nissan', 36.00, 50.00, 270.00, 3.00, 0.00);
INSERT INTO tariffa (nome_modello, produttore, supplemento_giornaliero, giornaliera, settimanale, oraria, chilometrica)
    VALUES ('Up', 'Volkswagen', 36.00, 47.00, 250.00, 2.75, 0.00);
INSERT INTO tariffa (nome_modello, produttore, supplemento_giornaliero, giornaliera, settimanale, oraria, chilometrica)
    VALUES ('Ducato 35', 'Fiat', 56.00, 80.00, 390.00, 3.90, 0.50);
INSERT INTO tariffa (nome_modello, produttore, supplemento_giornaliero, giornaliera, settimanale, oraria, chilometrica)
    VALUES ('GOLF SPORTVAN', 'Volkswagen', 41.00, 55.00, 390.00, 3.70, 0.50);

-- VETTURA
INSERT INTO vettura (targa, nome, colore, chilometraggio, seggiolini, trasporto_animali, nome_parcheggio, nome_modello,
                     produttore)
    VALUES ('3PPJ765', 'Alice', 'nero', 6486, 1, TRUE, 'Piazza cavour', 'Panda 1.3 Multijet', 'Fiat');
INSERT INTO vettura (targa, nome, colore, chilometraggio, seggiolini, trasporto_animali, nome_parcheggio, nome_modello,
                     produttore)
    VALUES ('7Z29X15', 'Lara', 'rosso', 8724, 0, TRUE, 'Villa borghese', 'Leaf', 'Nissan');
INSERT INTO vettura (targa, nome, colore, chilometraggio, seggiolini, trasporto_animali, nome_parcheggio, nome_modello,
                     produttore)
    VALUES ('7QFRF8R', 'Giulia', 'bianco', 20941, 0, FALSE, 'Piazza cavour', 'Panda 1.3 Multijet', 'Fiat');
INSERT INTO vettura (targa, nome, colore, chilometraggio, seggiolini, trasporto_animali, nome_parcheggio, nome_modello,
                     produttore)
    VALUES ('I4S30U7', 'Naomi', 'verde', 50169, 0, FALSE, 'Villa borghese', 'Leaf', 'Nissan');
INSERT INTO vettura (targa, nome, colore, chilometraggio, seggiolini, trasporto_animali, nome_parcheggio, nome_modello,
                     produttore)
    VALUES ('5ZEFX4X', 'Claire', 'blu', 65628, 0, FALSE, 'Pellico', 'Panda 1.3 Multijet', 'Fiat');
INSERT INTO vettura (targa, nome, colore, chilometraggio, seggiolini, trasporto_animali, nome_parcheggio, nome_modello,
                     produttore)
    VALUES ('E2F34I5', 'Monica', 'beige', 33032, 0, FALSE, 'Villa borghese', 'Up', 'Volkswagen');
INSERT INTO vettura (targa, nome, colore, chilometraggio, seggiolini, trasporto_animali, nome_parcheggio, nome_modello,
                     produttore)
    VALUES ('3PMSG8T', 'Marta', 'nero', 11543, 0, FALSE, 'Piazza rossa', 'GOLF SPORTVAN', 'Volkswagen');
INSERT INTO vettura (targa, nome, colore, chilometraggio, seggiolini, trasporto_animali, nome_parcheggio, nome_modello,
                     produttore)
    VALUES ('B2J32H5', 'Jennifer', 'giallo', 22511, 0, FALSE, 'Caboto', 'Ducato 35', 'Fiat');

-- ABBONAMENTO
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-06-10', '2019-07-10', 987654321, 'alice123@gmail.com', 20.00, 'Mensile', 1234);
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-07-11', '2019-08-11', 987654321, 'alice123@gmail.com', 20.00, 'Mensile', 1234);
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-07-13', '2019-08-01', 193053945, 'luca_rossi@gmail.com', 36.00, 'Mensile', 5576);
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-07-07', '2019-08-04', 203570453, 'giovanni93@gmail.com', 30.00, 'Mensile', 8900);
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-06-06', '2019-09-03', 174087365, 'abc@gmail.com', 40.00, 'Trimestrale', 2212);
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-07-22', '2019-08-13', 152074735, 'qwe@gmail.com', 40.00, 'Mensile', 5512);
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-07-24', '2019-11-11', 153986098, 'sara123@gmail.com', 20.00, 'Trimesrtale', 3476);
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-07-17', '2019-12-10', 345632908, 'ttt2@gmail.com', 40.00, 'Trimestrale', 7734);
INSERT INTO abbonamento (data_inizio, data_fine, num_smartcard, email, costo, tipo, carta_carburante)
    VALUES ('2019-07-28', '2019-08-09', 167945289, 'marco123@gmail.com', 20.00, 'Mensile', 9145);

-- PRENOTAZIONE

--PASSATE
INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-07-03 09:00:00.000', '2019-07-05 17:00:00.000', '3PPJ765', '2019-07-03 09:20:00.000',
            '2019-07-05 16:00:00.000', 0.00, 20, NULL, 'alice123@gmail.com');
INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-06-20 09:00:00.000', '2019-06-28 17:00:00.000', '3PPJ765', '2019-06-20 09:40:00.000',
            '2019-06-28 15:00:00.000', 0.00, 183, NULL, 'abc@gmail.com');
INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-06-29 15:00:00.000', '2019-06-30 11:00:00.000', 'E2F34I5', '2019-06-29 16:00:00.000',
            '2019-06-30 10:30:00.000', 0.00, 37, NULL, 'abc@gmail.com');
INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-07-25 17:00:00.000', '2019-08-30 09:00:00.000', 'I4S30U7', NULL, NULL, 0.00, 0,
            '2019-07-24 18:00:00.000',
            'sara123@gmail.com');
-- FUTURE
INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-07-10 13:00:00.000', '2019-07-15 16:00:00.000', '7QFRF8R', NULL, NULL, 0.00, 0, NULL,
            'abc@gmail.com');

INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-08-01 11:00:00.000', '2019-08-03 18:00:00.000', '5ZEFX4X', NULL, NULL, 0.00, 0, NULL,
            'marco123@gmail.com');
INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-07-11 12:00:00.000', '2019-07-12 09:00:00.000', '7Z29X15', NULL, NULL, 0.00, 0, NULL,
            'giovanni93@gmail.com');

-- RIFORNIMENTO
INSERT INTO rifornimento (data_rifornimento, targa, litri, chilometraggio)
    VALUES ('2019-07-13 00:00:00.000', '3PPJ765', 10, 90);

-- CONDUCENTE
INSERT INTO conducente (num_patente, codice_fiscale, categoria_patente, num_carta_identita, luogo_nascita, data_nascita,
                        cognome, nome, indirizzo_residenza, partita_iva)
    VALUES ('01234567', 'PBHFTO76W83M220J', 'B', '54321', 'Genova', '1993-04-12', 'Repetto', 'Sara',
            'via borgo nuovo 19, GE', NULL);
INSERT INTO conducente (num_patente, codice_fiscale, categoria_patente, num_carta_identita, luogo_nascita, data_nascita,
                        cognome, nome, indirizzo_residenza, partita_iva)
    VALUES ('09876132', NULL, 'B', '79399', 'Genova', '1990-01-01', 'Calcagno', 'Giorgio', 'via dodecaneso 33, GE',
            '18530718725');
INSERT INTO conducente (num_patente, codice_fiscale, categoria_patente, num_carta_identita, luogo_nascita, data_nascita,
                        cognome, nome, indirizzo_residenza, partita_iva)
    VALUES ('82639268', NULL, 'B', '82563', 'Genova', '1963-09-23', 'Barbieri', 'Filippo', 'via donghi 12, GE',
            '24136243257');
INSERT INTO conducente (num_patente, codice_fiscale, categoria_patente, num_carta_identita, luogo_nascita, data_nascita,
                        cognome, nome, indirizzo_residenza, partita_iva)
    VALUES ('10273791', NULL, 'B', '11583', 'Genova', '1969-08-22', 'Camera', 'Mattia', 'via matteotti 16, GE',
            '82031669341');
INSERT INTO conducente (num_patente, codice_fiscale, categoria_patente, num_carta_identita, luogo_nascita, data_nascita,
                        cognome, nome, indirizzo_residenza, partita_iva)
    VALUES ('25835023', 'PLTKXN68A48F476J', 'B', '96456', 'Genova', '1973-11-21', 'Priano', 'Alice',
            'via torino 10, GE', NULL);
INSERT INTO conducente (num_patente, codice_fiscale, categoria_patente, num_carta_identita, luogo_nascita, data_nascita,
                        cognome, nome, indirizzo_residenza, partita_iva)
    VALUES ('44682902', 'BRKAUK31P67F160X', 'B', '23756', 'Genova', '1975-12-20', 'Alfieri', 'Marco',
            'corso saracco 47, GE', NULL);
INSERT INTO conducente (num_patente, codice_fiscale, categoria_patente, num_carta_identita, luogo_nascita, data_nascita,
                        cognome, nome, indirizzo_residenza, partita_iva)
    VALUES ('17794562', 'NABRMD43A11F921T', 'B', '12876', 'Genova', '1988-01-27', 'Rossi', 'Luca',
            'via san paolo 33, GE', NULL);
INSERT INTO conducente (num_patente, codice_fiscale, categoria_patente, num_carta_identita, luogo_nascita, data_nascita,
                        cognome, nome, indirizzo_residenza, partita_iva)
    VALUES ('03785929', 'SRTRNH55P21F080Q', 'B', '23450', 'Genova', '1982-05-02', 'Ronco', 'Giovanni',
            'via tommasini 11, GE', NULL);

-----------------------------------------------------------------------------------------------------------------------

-- TRIGGER

-- Controlla se un utente ha un abbonamento attivo al momento dell'inserimento o dell'aggiornamento di una tupla in abbonamenti

CREATE OR REPLACE FUNCTION ABBONAMENTO_ATTIVO() RETURNS TRIGGER AS
$$
BEGIN
    PERFORM * FROM abbonamento WHERE email = new.email AND data_fine > new.data_inizio;
    IF found THEN RAISE EXCEPTION '% ha già un abbonamento attivo nel periodo selezionato!' , new.email; END IF;
    RETURN new;
END
$$ LANGUAGE PLPGSQL;

DROP TRIGGER IF EXISTS trigger_abbonamento_attivo ON abbonamento;

CREATE TRIGGER trigger_abbonamento_attivo
    BEFORE INSERT OR UPDATE
    ON abbonamento
    FOR EACH ROW
EXECUTE PROCEDURE ABBONAMENTO_ATTIVO();

---------------------------------------------------------------------------------------------------

-- Controlla se un utente ha associata una modalita di pagamento al momento dell' inserimento o aggiornamento di una tupla in abbonamento

CREATE OR REPLACE FUNCTION modalita_pagamento() RETURNS TRIGGER AS
$$
BEGIN
    IF exists(SELECT * FROM utente WHERE email = new.email AND ammontare > 0) THEN
        RETURN new;
    ELSIF exists(SELECT * FROM rid WHERE email = new.email) THEN
        RETURN new;
    ELSIF exists(SELECT * FROM carta_di_credito WHERE email = new.email) THEN
        RETURN new;
    ELSE
        RAISE EXCEPTION '% non ha una nessuna modalita di pagamento!' , new.email;
    END IF;
END
$$ LANGUAGE PLPGSQL;

DROP TRIGGER IF EXISTS trigger_modalita_pagamento ON abbonamento;

CREATE TRIGGER trigger_modalita_pagamento
    BEFORE INSERT OR UPDATE
    ON abbonamento
    FOR EACH ROW
EXECUTE PROCEDURE modalita_pagamento();

-------------------------------------------------------------------------------------------------------

-- Al momento della prenotazione controlla se l'utente ha un abbonamento valido (la data ritiro deve essere sucessiva alla data di inizio dell'abbonamento)

CREATE OR REPLACE FUNCTION abbonamento_valido() RETURNS TRIGGER AS
$$
BEGIN
    PERFORM *
        FROM abbonamento
        WHERE new.email = abbonamento.email AND new.data_consegna <= data_fine AND new.data_ritiro >= data_inizio;
    IF NOT found THEN RAISE EXCEPTION '% non ha un abbonamento valido!', new.email; END IF;
    RETURN new;
END;
$$ LANGUAGE 'plpgsql';

DROP TRIGGER IF EXISTS trigger_abbonamento_valido ON prenotazione;

CREATE TRIGGER trigger_abbonamento_valido
    BEFORE INSERT OR UPDATE
    ON prenotazione
    FOR EACH ROW
EXECUTE PROCEDURE abbonamento_valido();

--------------------------------------------------------------------------------------------------------

-- Controlla se un conducente e' associato o a un codice fiscale o a una partita Iva

CREATE OR REPLACE FUNCTION conducente() RETURNS TRIGGER AS
$$
BEGIN
    IF ((new.partita_iva IS NOT NULL AND new.codice_fiscale IS NOT NULL)
            OR new.partita_iva IS NULL AND new.codice_fiscale IS NULL) THEN
        RAISE EXCEPTION 'Un conducente deve essere associato o a un codice fiscale o a una partita iva!';
    END IF;
    RETURN new;
END
$$ LANGUAGE PLPGSQL;

DROP TRIGGER IF EXISTS trigger_conducente ON conducente;

CREATE TRIGGER trigger_conducente
    BEFORE INSERT OR UPDATE
    ON conducente
    FOR EACH ROW
EXECUTE PROCEDURE conducente();
----------------------------------------------------------------------------------------------------------

-- Controlla se il conducente addizionale ha lo stesso indirizzo di residenza del privato a cui e' associato

CREATE OR REPLACE FUNCTION conducente_addizionale() RETURNS TRIGGER AS
$$
BEGIN
    IF (new.partita_iva IS NOT NULL) THEN RETURN new; END IF;
    IF NOT EXISTS(SELECT *
                      FROM privato
                      WHERE codice_fiscale = new.codice_fiscale AND indirizzo_residenza = new.indirizzo_residenza) THEN
        RAISE EXCEPTION 'Indirizzo e residenza di % non combaciano con i dati in privato!' , new.codice_fiscale;
    END IF;
    RETURN new;
END
$$ LANGUAGE PLPGSQL;

DROP TRIGGER IF EXISTS trigger_conducente_addizionale ON conducente;

CREATE TRIGGER trigger_conducente_addizionale
    BEFORE INSERT OR UPDATE
    ON conducente
    FOR EACH ROW
EXECUTE PROCEDURE conducente_addizionale();
-------------------------------------------------------------------------------------------------------------

-- Quando si inserisce una data di annullamento controlla che i campi di utilizzo efettivo non sia stati popolati

CREATE OR REPLACE FUNCTION annullamento_prenotazione() RETURNS TRIGGER AS
$$
BEGIN
    IF (new.data_annullamento IS NOT NULL AND (new.data_ritiro_e IS NOT NULL OR new.data_consegna_e IS NOT NULL)) THEN
        RAISE EXCEPTION 'Non si puo annullare una prenotazione in utilizzo';
    END IF;
    RETURN new;
END
$$ LANGUAGE PLPGSQL;

DROP TRIGGER IF EXISTS trigger_annullamento_prenotazione ON prenotazione;

CREATE TRIGGER trigger_annullamento_prenotazione
    AFTER INSERT OR UPDATE
    ON prenotazione
    FOR EACH ROW
EXECUTE PROCEDURE annullamento_prenotazione();
----------------------------------------------------------------------------------------------------------------

-- Quando si inserisce una prenotazione controlla che un' auto non sia gia' prenotata

CREATE OR REPLACE FUNCTION auto_prenotate() RETURNS TRIGGER AS
$$
BEGIN
    IF exists(SELECT *
                  FROM prenotazione
                  WHERE (new.data_ritiro BETWEEN data_ritiro AND data_consegna) AND new.targa = targa and id <> new.id) THEN
        RAISE EXCEPTION 'La vettura con targa % e gia prenotata!', new.targa;
    END IF;
    RETURN new;
END;
$$ LANGUAGE 'plpgsql';

DROP TRIGGER IF EXISTS trigger_auto_prenotate ON prenotazione;

CREATE TRIGGER trigger_auto_prenotate
    BEFORE INSERT OR UPDATE
    ON prenotazione
    FOR EACH ROW
EXECUTE PROCEDURE auto_prenotate();
-----------------------------------------------------------------------------------------------------------------

-- Quando si inserisce una vettura controlla se il parcheggio assegnato ha posti disponibili

CREATE OR REPLACE FUNCTION capacita_parcheggio() RETURNS TRIGGER AS
$$
DECLARE
    max INT = (SELECT num_posti
                   FROM parcheggio
                   WHERE nome = new.nome_parcheggio);
BEGIN
    IF ((SELECT count(*) FROM vettura WHERE nome_parcheggio = new.nome_parcheggio) >= max) THEN
        RAISE EXCEPTION 'Parcheggio pieno!';
    END IF;
    RETURN new;
END;
$$ LANGUAGE 'plpgsql';

DROP TRIGGER IF EXISTS trigger_capacita_parcheggio ON vettura;

CREATE TRIGGER trigger_capacita_parcheggio
    BEFORE INSERT OR UPDATE
    ON vettura
    FOR EACH ROW
EXECUTE PROCEDURE capacita_parcheggio();
------------------------------------------------------------------------------------------------------------------

-- Quando viene inserita una vettura controlla che il parcheggio assegnato permetta auto di quel tipo

CREATE OR REPLACE FUNCTION tipo_parcheggio() RETURNS TRIGGER AS
$$
DECLARE
    type VARCHAR = (SELECT tipo
                        FROM modello
                            JOIN vettura USING (nome_modello, produttore)
                        WHERE modello = new.nome_modello AND produttore = new.produttore);
BEGIN
    IF NOT exists(SELECT * FROM ospita WHERE nome_parcheggio = nome AND type = tipo) THEN
        RAISE EXCEPTION 'Il parcheggio % non ammette vetture di tipo %!', new.nome_parcheggio, type;
    END IF;
    RETURN new;
END;
$$ LANGUAGE 'plpgsql';

DROP TRIGGER IF EXISTS trigger_tipo_parcheggio ON vettura;

CREATE TRIGGER trigger_tipo_parcheggio
    BEFORE INSERT OR UPDATE
    ON vettura
    FOR EACH ROW
EXECUTE PROCEDURE tipo_parcheggio();
------------------------------------------------------------------------------------------------------------------

-- Vista per le prenotazioni concluse

CREATE OR REPLACE VIEW prenotazioni_conluse AS
    SELECT id, email, extract(DAYS FROM (data_consegna - data_ritiro)) AS giorni,
           extract(HOURS FROM (data_consegna - data_ritiro)) AS ore,
           extract(DAYS FROM (data_consegna_e - data_consegna)) AS giorni_extra,
           extract(HOURS FROM (data_consegna_e - data_consegna)) AS ore_extra, km_percorsi, data_annullamento,
           settimanale, giornaliera, oraria, chilometrica, supplemento_giornaliero, bonus, penale,
           extract(YEARS FROM age(data_nascita)) AS eta, data_consegna_mod - data_consegna AS datadiff
        FROM prenotazione
            FULL OUTER JOIN vettura USING (targa)
            FULL OUTER JOIN modello USING (nome_modello, produttore)
            FULL OUTER JOIN tariffa USING (nome_modello, produttore)
            FULL OUTER JOIN utente USING (email)
            FULL OUTER JOIN privato USING (email)
            FULL OUTER JOIN conducente USING (codice_fiscale)
        WHERE (data_annullamento IS NOT NULL AND data_ritiro - data_annullamento < INTERVAL '24 hours')
           OR data_consegna_e IS NOT NULL;
------------------------------------------------------------------------------------------------------------------
-- FUNZIONI

-- Funzione che calcola il prezzo totale di una prenotazione

CREATE OR REPLACE FUNCTION fatturazione()
    RETURNS TABLE (
        id INT,
        prezzo_finale NUMERIC(6, 2)
    )
AS
$$
DECLARE
    var_f RECORD;
BEGIN
    FOR var_f IN (SELECT * FROM prenotazioni_conluse)
        LOOP
            id = var_f.id;
            IF (var_f.giorni = 0) THEN
                prezzo_finale = var_f.oraria * var_f.ore + var_f.chilometrica * var_f.km_percorsi;
            ELSEIF (var_f.giorni <= 7) THEN
                IF (var_f.bonus) THEN
                    prezzo_finale = var_f.chilometrica * var_f.km_percorsi;
                ELSE
                    prezzo_finale = var_f.giornaliera * var_f.giorni + var_f.chilometrica * var_f.km_percorsi;
                END IF;
            ELSEIF (var_f.giorni > 7) THEN
                prezzo_finale = (var_f.settimanale * var_f.giorni / 7::INT)
                        + var_f.supplemento_giornaliero * (var_f.giorni::INT % 7);
            END IF;
            IF (var_f.giorni_extra < 0) THEN
                prezzo_finale = prezzo_finale + 0.5 * (var_f.giornaliera * abs(var_f.giorni_extra));
            END IF;
            IF (var_f.giorni_extra > 0) THEN prezzo_finale = prezzo_finale + var_f.penale; END IF;
            IF (var_f.data_annullamento IS NOT NULL) THEN prezzo_finale = 0.5 * prezzo_finale; END IF;
            IF (var_f.eta < 26) THEN prezzo_finale = prezzo_finale * 0.9; END IF;
            IF (var_f.datadiff IS NOT NULL) THEN
                prezzo_finale = prezzo_finale + 0.5 * (var_f.giornaliera * var_f.datadiff);
            END IF;
            RETURN NEXT;
        END LOOP;
END;
$$ LANGUAGE PLPGSQL;
------------------------------------------------------------------------------------------------------------------

--Funzione per la modifica di una consegna

CREATE OR REPLACE FUNCTION modifica_consegna(idd INT, d TIMESTAMP) RETURNS VOID AS
$$
DECLARE
    var_rit TIMESTAMP = (SELECT prenotazione.data_ritiro
                             FROM prenotazione
                             WHERE id = idd);
    var_cons TIMESTAMP = (SELECT prenotazione.data_consegna
                              FROM prenotazione
                              WHERE id = idd);
BEGIN
    IF NOT exists(SELECT * FROM prenotazione WHERE id = idd) THEN RAISE EXCEPTION 'Invalid id!'; END IF;
    IF (d > var_cons) THEN RAISE EXCEPTION 'Invalid date!'; END IF;
    IF (current_date - var_rit < INTERVAL '24 hours') THEN
        UPDATE prenotazione SET data_consegna_mod = data_consegna, data_consegna = d WHERE id = idd;
    ELSE
        UPDATE prenotazione SET data_consegna = d WHERE id = idd;
    END IF;
    RETURN;
END;
$$ LANGUAGE PLPGSQL;
------------------------------------------------------------------------------------------------------------------

-- Funzione che ritorna il numero di prentazioni efettuate per ogni mese

CREATE OR REPLACE FUNCTION prenotazioni_mensili()
    RETURNS TABLE (
        mese INT,
        num_prenotazioni INT
    )
AS
$$
BEGIN
    FOR d IN 1..12
        LOOP
            num_prenotazioni =
                    (SELECT count(*) FROM prenotazione WHERE extract(MONTH FROM prenotazione.data_ritiro) = d);
            mese = d;
            RETURN NEXT;
        END LOOP;
END;
$$ LANGUAGE plpgsql;
---------------------------------------------------------------------------------------------------------------

-- Ritorna tutte le auto disponibili di un certo tipo in una precisa data

CREATE OR REPLACE FUNCTION auto_disponibili(ttipo VARCHAR(20), ttimestamp TIMESTAMP)
    RETURNS TABLE (
        targha VARCHAR(7),
        produttore VARCHAR(20),
        modello VARCHAR(20)
    )
AS
$$
BEGIN
    RETURN QUERY (SELECT targa, vettura.produttore, vettura.nome_modello
                      FROM vettura
                          JOIN modello m ON vettura.nome_modello = m.nome_modello AND vettura.produttore = m.produttore
                      WHERE targa NOT IN (SELECT targa
                                              FROM prenotazione
                                              WHERE ttimestamp BETWEEN data_ritiro AND data_consegna)
                        AND m.tipo ILIKE $1);
END ;
$$ LANGUAGE plpgsql;
----------------------------------------------------------------------------------------------------------------

-- QUERY

ALTER TABLE privato
    ADD CONSTRAINT privato_genere_check CHECK (genere LIKE 'm' OR genere LIKE 'f');

--1. INTERROGAZIONI SEMPLICI

-- PORZIONE B

--1. Si decide di selezionare tutte le prenotazioni con penale zero

SELECT targa, data_ritiro
    FROM prenotazione
    WHERE prenotazione.penale = '0';

--2. Selezionare tutti gli utenti che non hanno un annullamento di prenotazione

SELECT DISTINCT email
    FROM prenotazione
    WHERE data_annullamento IS NULL;

--3. Determinare tutte le prenotazioni effettuate da un utente con mail che inizia con la lettera a

SELECT targa, email
    FROM prenotazione
    WHERE email LIKE 'a%';

-- PORZIONE COMUNE

--1. Si seleziona la targa delle vetture che non hanno parcheggiato nel parcheggio 'Villa borghese' (con differenza)

SELECT targa
    FROM vettura EXCEPT
SELECT targa
    FROM vettura
    WHERE nome_parcheggio ILIKE 'Villa borghese';

--2. Per ogni email viene ritornato il relativo codice fiscale o partita iva (con outer join)

SELECT utente.email, privato.codice_fiscale, azienda.partita_iva
    FROM utente
        LEFT OUTER JOIN privato ON utente.email = privato.email
        LEFT OUTER JOIN azienda ON utente.email = azienda.email;

--3. Si selezionano tutti gli abbonamenti effettuati a partire dal 1 giugno(compreso)

SELECT *
    FROM abbonamento
    WHERE data_inizio > '2019-05-31';


--2. INTERROGAZIONI DI MANIPOLAZIONE

--1. Si decide di cancellare tutte le prenotazioni avvenute nel mese di aprile (cancellazione)

DELETE
    FROM prenotazione
    WHERE data_consegna BETWEEN '2019-03-31' AND '2019-04-30';

--2. Si inserisce una nuova prenotazione (inserimento) FALLISCE PERCHE NON RISPETTA I VINCOLI

INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-07-15 07:00:00.000', '2019-07-18 11:00:00.000', '3PPJ765', NULL, NULL, 0.00, 0, NULL,
            'luca_rossi@gmail.com');

--3. Aumentare la penale del 10% per le prenotazioni avvenute dopo il '31/07/2019' (modifica)

UPDATE prenotazione
SET penale=penale * 1.1
    WHERE data_ritiro > '2019-07-31';

-- PORZIONE COMUNE

--1. Inserimento di un nuovo parcheggio (inserimento)

INSERT INTO parcheggio (nome, longitudine, latitudine, zona, indirizzo, num_posti)
    VALUES ('Garibaldi', '88', '20', 'principe', 'corso garibaldi 24', 26);

--2. Cancellare i clienti che non hanno effettuato abbonamenti dopo il 30/04/2019

DELETE
    FROM utente
    WHERE email NOT IN (SELECT email FROM abbonamento WHERE data_inizio > '2019-04-30');

--3. Modificare la numerosità del parcheggio Garibaldi a 32

UPDATE parcheggio
SET num_posti='32'
    WHERE nome ILIKE 'garibaldi';

--3. INTERROGAZIONI DI ANALISI

--1. Si decide di selezionare tutte le auto (con i relativi parcheggi) che hanno più di una prenotazione (raggruppamento)

SELECT prenotazione.targa, vettura.nome_parcheggio, COUNT(*)
    FROM prenotazione
        JOIN vettura ON prenotazione.targa = vettura.targa
    WHERE data_annullamento IS NULL
    GROUP BY prenotazione.targa, vettura.nome_parcheggio
    HAVING COUNT(*) > 1
    ORDER BY prenotazione.targa;

--2. Determinare le vetture che hanno lo stesso modello della vettura con targa '3PPJ765' (sottointerrogazione)

SELECT targa
    FROM vettura
    WHERE nome_modello = (SELECT nome_modello FROM vettura WHERE targa = '3PPJ765');

--3. Si selezionano tutti gli annulamenti effettuati da ogni utenti (raggruppamento)

SELECT email, data_annullamento
    FROM prenotazione
    WHERE data_annullamento IS NOT NULL
    GROUP BY email, data_annullamento;

-- PORZIONE COMUNE

--1. Determinare il numero di abbonamenti e costo minimo e massimo (funzioni di gruppo)

SELECT count(*) AS num_abbonamenti, MIN(costo), max(costo)
    FROM abbonamento;

--2. Determinare gli utenti che hanno prenotato tutte le vetture di colore nero (divisione)

SELECT email
    FROM prenotazione
        NATURAL JOIN utente
        JOIN vettura ON prenotazione.targa = vettura.targa
    WHERE colore ILIKE 'nero'
    GROUP BY email
    HAVING count(DISTINCT vettura.targa) = (SELECT count(DISTINCT targa) FROM vettura WHERE colore ILIKE 'nero');

--3. Clacola il costo medio di tutti gli abbonamenti (funzioni di gruppo)

SELECT avg(costo) AS costo_medio_abbonamento
    FROM abbonamento;

-- query
SELECT targa, produttore, nome_modello
    FROM vettura
    WHERE targa NOT IN (SELECT targa FROM prenotazione WHERE current_date BETWEEN data_ritiro AND data_consegna);
-----------------------------------------------------------------------------------
SELECT *
    FROM prenotazioni_mensili();
----------------------------------
SELECT *
    FROM auto_disponibili('city car', '2019-07-11 02:00:00.000');
------------------------------------------------------------------------------------------------------------------
SELECT *
    FROM fatturazione();
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-- QUERY CHE FALLISCONO
--
/*
INSERT INTO prenotazione (data_ritiro, data_consegna, targa, data_ritiro_e, data_consegna_e, penale, km_percorsi,
                          data_annullamento, email)
    VALUES ('2019-07-15 10:00:00.000', '2019-08-18 10:00:00.000', '7Z29X15', NULL, NULL, 0.00, 0, NULL,
            'giovanni93@gmail.com');
----------------------------------------------------------------------------------
--
SELECT modifica_consegna(11, '2019-07-23 02:00:00.000');
*/